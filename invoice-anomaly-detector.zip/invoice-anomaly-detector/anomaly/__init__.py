"""Synthetic carrier-invoice audit toolkit."""
